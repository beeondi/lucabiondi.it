document.querySelectorAll('[data-i18n]').forEach((el) => {
  el.textContent = chrome.i18n.getMessage(el.dataset.i18n);
});

const toggle = document.getElementById('toggle');

chrome.storage.local.get('enabled').then(({ enabled = true }) => {
  toggle.checked = enabled;
});

// Il content script di ogni scheda ascolta storage.onChanged e si aggiorna da solo.
toggle.addEventListener('change', () => {
  chrome.storage.local.set({ enabled: toggle.checked });
});
