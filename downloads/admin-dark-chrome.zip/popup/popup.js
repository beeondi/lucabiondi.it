document.querySelectorAll('[data-i18n]').forEach((el) => {
  el.textContent = chrome.i18n.getMessage(el.dataset.i18n);
});

const toggle = document.getElementById('toggle');

chrome.storage.local.get('enabled').then(({ enabled = true }) => {
  toggle.checked = enabled;
});

toggle.addEventListener('change', () => {
  chrome.runtime.sendMessage({ type: 'toggle', enabled: toggle.checked });
});
