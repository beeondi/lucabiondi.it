// Il CSS è sempre iniettato dal manifest (document_start, nessun flash).
// Qui si gestisce solo lo stato on/off tramite un attributo su <html>.
(() => {
  const root = document.documentElement;
  const apply = (enabled) => {
    if (enabled) root.removeAttribute('data-admin-dark');
    else root.setAttribute('data-admin-dark', 'off');
  };
  chrome.storage.local.get('enabled').then(({ enabled = true }) => apply(enabled));
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && 'enabled' in changes) apply(changes.enabled.newValue !== false);
  });
})();
