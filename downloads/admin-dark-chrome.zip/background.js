// Registra/deregistra il CSS come content script dinamico (document_start → nessun flash bianco)
// e lo applica/rimuove subito sulle tab admin già aperte.

const SCRIPT_ID = 'admin-dark-css';
const MATCHES = ['https://admin.shopify.com/*'];
const CSS_FILES = ['css/dark.css'];

async function isEnabled() {
  const { enabled = true } = await chrome.storage.local.get('enabled');
  return enabled;
}

async function syncRegistration(enabled) {
  const existing = await chrome.scripting.getRegisteredContentScripts({ ids: [SCRIPT_ID] });
  if (enabled && existing.length === 0) {
    await chrome.scripting.registerContentScripts([{
      id: SCRIPT_ID,
      matches: MATCHES,
      css: CSS_FILES,
      runAt: 'document_start',
      allFrames: false,
      persistAcrossSessions: true
    }]);
  } else if (!enabled && existing.length > 0) {
    await chrome.scripting.unregisterContentScripts({ ids: [SCRIPT_ID] });
  }
}

async function applyToOpenTabs(enabled) {
  const tabs = await chrome.tabs.query({ url: MATCHES });
  await Promise.all(tabs.map(async (tab) => {
    try {
      const target = { tabId: tab.id };
      if (enabled) await chrome.scripting.insertCSS({ target, files: CSS_FILES });
      else await chrome.scripting.removeCSS({ target, files: CSS_FILES });
    } catch (e) { /* tab non accessibile: ignorata */ }
  }));
}

async function updateBadge(enabled) {
  await chrome.action.setBadgeText({ text: enabled ? '' : 'OFF' });
  await chrome.action.setBadgeBackgroundColor({ color: '#616161' });
}

async function init() {
  const enabled = await isEnabled();
  await syncRegistration(enabled);
  await updateBadge(enabled);
}

chrome.runtime.onInstalled.addListener(init);
chrome.runtime.onStartup.addListener(init);

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== 'toggle') return;
  (async () => {
    const enabled = !!msg.enabled;
    await chrome.storage.local.set({ enabled });
    await syncRegistration(enabled);
    await applyToOpenTabs(enabled);
    await updateBadge(enabled);
    sendResponse({ ok: true, enabled });
  })();
  return true;
});
