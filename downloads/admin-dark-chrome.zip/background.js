// All'installazione/aggiornamento i content script non entrano nelle schede già aperte:
// li iniettiamo noi, così il dark è attivo subito senza ricaricare.

const MATCHES = ['https://admin.shopify.com/*'];

async function injectIntoOpenTabs() {
  const tabs = await chrome.tabs.query({ url: MATCHES });
  await Promise.all(tabs.map(async (tab) => {
    const target = { tabId: tab.id };
    try {
      await chrome.scripting.insertCSS({ target, files: ['css/dark.css'] });
      await chrome.scripting.executeScript({ target, files: ['content.js'] });
    } catch (e) { /* scheda non accessibile (es. scartata): ignorata */ }
  }));
}

async function updateBadge(enabled) {
  await chrome.action.setBadgeText({ text: enabled ? '' : 'OFF' });
  await chrome.action.setBadgeBackgroundColor({ color: '#616161' });
}

async function refreshBadge() {
  const { enabled = true } = await chrome.storage.local.get('enabled');
  await updateBadge(enabled);
}

chrome.runtime.onInstalled.addListener(async () => {
  await injectIntoOpenTabs();
  await refreshBadge();
});
chrome.runtime.onStartup.addListener(refreshBadge);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && 'enabled' in changes) updateBadge(changes.enabled.newValue !== false);
});
